<?php
require_once("query.php");
class Sites extends QueryBuilder
{
    public $from = "sites ";
}
?>
<?php
require_once("query.php");
class Clients extends QueryBuilder
{
    public $from = "clients ";
}
?>